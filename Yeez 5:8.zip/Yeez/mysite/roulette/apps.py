from django.apps import AppConfig


class RouletteConfig(AppConfig):
    name = 'roulette'
